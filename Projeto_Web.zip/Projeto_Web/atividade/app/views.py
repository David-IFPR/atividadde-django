from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as login_dj, logout as logout_dj
from .models import *

def index(request):
    return render(request, 'index.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()
        
        if username and password:
            user = authenticate(username=username, password=password)
            if not user:
                print('no user')
                for u in User.objects.all():
                    print(u.username, u.password)
                return render(request, 'login.html', {'error': 'Usuário não cadastrado!'})

            login_dj(request, user)
            return redirect('minhas-viagens')

        return render(request, 'login.html', {'error': 'Preencher formulário!'})

    return render(request, 'login.html')

def register(request):
    if request.method == 'POST':
        username = request.POST["username"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm-password"]
        
        if username and password and confirm_password:
            user = User.objects.filter(username=username).first()
            if user:
                return render(request, 'register.html', {'erro': 'Usuário já cadastrado!'})
            
            if password != confirm_password:
                return render(request, 'register.html', {'erro': 'Senhas não coindizem!'})
            
            user = User.objects.create_user(username=username, password=password)
            return redirect('login')
        
        return render(request, 'register.html', {'erro': 'Preencher formulário!'})
        
    return render(request, 'register.html')


@login_required(login_url='/login/')
def minhas_viagens(request):
    viagens = Viagem.objects.filter(usuario=request.user)
    return render(request, 'minhas-viagens.html', {'viagens': viagens})

@login_required(login_url='/login/')
def logout(request):
    logout_dj(request)
    return redirect('login')